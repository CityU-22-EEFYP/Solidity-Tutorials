import React from 'react';

const SearchBar = () => {
  return <input />;
};

export default SearchBar;
